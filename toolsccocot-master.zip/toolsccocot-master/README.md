# Instagram Bot Tools Ccocot
 Sebuah Tools Bot Instagram

# How to install on Termux
* pkg install nodejs
* pkg install php
* pkg install bash
* pkg install git
* git clone https://github.com/fikrifar/toolsccocot
* cd toolscoccot
* unzip node_modules.zip

# How to Run on Termux
* bash run

# How To Fix Error Bash Run
* pkg install figlet
* pkg install ruby
* pkg install lolcat
* gem install lolcat

# How To Fix Error Unfollow Not Follow Back (Number 7)
* cd toolsccocot
* mv unfollnotfollowback.js unfollownotfollowback.js
* bash run

And select number 7


# Thank's To:

Ccocot & NaonlahNet & Bc0de.net & Wingkocoli & Dandy & Jrxuii & Auliaahmad16 & Huttarichard

# Follow 
* Instagram = https://www.instagram.com/mazfikri001
* Facebook  = https://www.facebook.com/mazfikri001
